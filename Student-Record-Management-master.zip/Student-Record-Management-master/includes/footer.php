<footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="http://www.gndpoly.org/">
                  GNDPC
                </a>
              </li>
              <li>
                <a href="documentation.php">
                  Documentation
                </a>
              </li>
              <li>
                <a href="creators.php">
                  Creators
                </a>
              </li>
              
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="#">Computer Trade 3rd Year</a> for a better web.
          </div>
        </div>
      </footer>