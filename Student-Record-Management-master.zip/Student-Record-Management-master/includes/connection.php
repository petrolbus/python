<?php
$conn = new mysqli("localhost","root","","gndpc_attendance");
?>